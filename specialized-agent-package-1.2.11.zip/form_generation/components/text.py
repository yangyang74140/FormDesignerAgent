"""Text-family properties, compound text limits and Input-only validation."""
from __future__ import annotations

from typing import Any, Mapping

from .common import PropertyRule, boolean, default_snapshot, enum, number, simulate_default, string, validate_default
from .validation import reject, validate_schema

INPUT_FORMATS = ["none", "chinese", "number", "letter", "letter_num", "phone", "tel", "postcode", "idcard", "email"]
_LENGTH_SCHEMA = {"type": "number", "minimum": 1}
PROPERTIES = {
    "placeholder": string(reset="", has_reset=True),
    "defaultValue": PropertyRule(),
    "textLengthLimit": number(1, reset={"enabled": False, "maxLength": 200}, has_reset=True, unvalidated_operations=("clear",)),
    "showLimitHint": boolean(),
    "textMaxLength": number(1, default=200, has_default=True, prerequisite="showLimitHint"),
    "enableQuickCopy": boolean(),
    "enableLinkParser": boolean(),
}
OVERRIDES = {
    "Input": {
        "allowClear": boolean(reset=False, has_reset=True),
        "isUnique": boolean(handler_required=True),
        "uniqueMessage": string(prerequisite="isUnique"),
        "format": enum(INPUT_FORMATS, reset="none", has_reset=True),
        "formatMessage": string(),
        "formatValidation": PropertyRule(),
    },
    "Input.TextArea": {
        "rows": number(3, 10, default=3, has_default=True),
        "disableAutoHeight": boolean(),
        "showEmptyLines": boolean(),
    },
}


def snapshot(node: Mapping[str, Any], prop: str) -> dict[str, Any] | None:
    props = node.get("props", {})
    if prop == "defaultValue":
        return default_snapshot(props)
    if prop == "textLengthLimit":
        return {"exists": True, "value": {"enabled": props.get("showLimitHint", False), **({"maxLength": props["textMaxLength"]} if "textMaxLength" in props else {})}} if "showLimitHint" in props or "textMaxLength" in props else {"exists": False}
    if prop == "formatValidation":
        return {"exists": True, "value": {"format": props["format"], **({"message": props["formatMessage"]} if "formatMessage" in props else {})}} if "format" in props else {"exists": False}
    return None


def normalize_set(node: Mapping[str, Any], prop: str, value: Any) -> Any:
    if prop == "formatValidation" and isinstance(value, dict) and "message" not in value and "formatMessage" in node.get("props", {}):
        value["message"] = node["props"]["formatMessage"]
    return value


def clear(node: Mapping[str, Any], prop: str) -> dict[str, Any] | None:
    props = node.get("props", {})
    if prop == "defaultValue":
        return {"exists": True, "value": {"mode": "undefined"}}
    if prop == "textLengthLimit":
        return {"exists": True, "value": {"enabled": False, **({"maxLength": props["textMaxLength"]} if "textMaxLength" in props else {})}}
    if prop == "formatValidation":
        return {"exists": True, "value": {"format": "none", **({"message": props["formatMessage"]} if "formatMessage" in props else {})}}
    if prop == "format" and node["componentName"] == "Input":
        return {"exists": True, "value": "none"}
    return None


def validate(node: Mapping[str, Any], prop: str, value: Any) -> bool:
    if prop == "defaultValue":
        validate_default(value, "string")
    elif prop == "textLengthLimit":
        if isinstance(value, dict):
            validate_schema(value, {"type": "object", "properties": {"enabled": {"const": False}, "maxLength": _LENGTH_SCHEMA}, "required": ["enabled"], "additionalProperties": False})
        else:
            validate_schema(value, _LENGTH_SCHEMA)
    elif prop == "formatValidation":
        validate_schema(value, {"type": "object", "properties": {"format": {"type": "string", "enum": INPUT_FORMATS}, "message": {"type": "string"}}, "required": ["format"], "additionalProperties": False})
    else:
        return False
    return True


def simulate(node: dict[str, Any], prop: str, after: Mapping[str, Any]) -> list[str] | None:
    props, value = node["props"], after.get("value")
    if prop == "defaultValue":
        return simulate_default(props, value)
    if prop == "textLengthLimit":
        enabled = not isinstance(value, dict)
        props["showLimitHint"] = enabled
        if enabled:
            props["textMaxLength"] = value
        elif "maxLength" in value:
            props["textMaxLength"] = value["maxLength"]
        return ["成组更新计数器与输入长度限制；关闭时保留历史阈值"]
    if prop == "formatValidation":
        props["format"] = value["format"]
        if "message" in value:
            props["formatMessage"] = value["message"]
        return ["同步内置格式校验及提示，不创建任意 rules 数组"]
    return None


def validate_candidate(node: Mapping[str, Any], prop: str) -> None:
    if prop == "formatMessage" and node.get("props", {}).get("format", "none") == "none":
        reject("PROPERTY_CONDITION_UNMET", "格式提示需要启用格式校验。", True)


def dependencies(prop: str) -> tuple[str, ...]:
    return ("format",) if prop == "formatMessage" else ()


def normalize_copy(prop: str, value: Any) -> Any:
    if prop == "textLengthLimit" and isinstance(value, dict) and value.get("enabled") is True:
        return value.get("maxLength")
    return value


def matches(prop: str, actual: Mapping[str, Any], after: Mapping[str, Any]) -> bool:
    if prop == "textLengthLimit":
        expected = after["value"]
        return actual.get("value", {}).get("enabled") is False if isinstance(expected, dict) else actual.get("value", {}).get("enabled") is True and actual["value"].get("maxLength") == expected
    return actual == after
