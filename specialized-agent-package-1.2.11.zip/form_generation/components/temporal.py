"""Date/time-family defaults, formats, ranges and derived placeholder rules."""
from __future__ import annotations

from datetime import datetime
from typing import Any, Mapping

from .common import PropertyRule, boolean, default_snapshot, enum, number, simulate_default, string, validate_default
from .validation import reject, validate_schema

PROPERTIES = {
    "defaultValue": PropertyRule(),
    "allowClear": boolean(reset=True, has_reset=True),
    "minTimeCondition": PropertyRule(handler_required=True),
    "maxTimeCondition": PropertyRule(handler_required=True),
}
OVERRIDES = {
    "DatePicker": {
        "placeholder": string(reset="年-月-日", has_reset=True),
        "format": enum(["YYYY", "YYYY-MM", "YYYY-MM-DD", "YYYY-MM-DD HH", "YYYY-MM-DD HH:mm", "YYYY-MM-DD HH:mm:ss"], reset="YYYY-MM-DD", has_reset=True, saved_lock=True),
        "disabledDays": PropertyRule(handler_required=True),
    },
    "TimePicker": {
        "placeholder": string(reset="请选择时间", has_reset=True),
        "format": enum(["HH:mm:ss", "HH:mm"], reset="HH:mm:ss", has_reset=True, saved_lock=True),
        "minuteStep": number(1, 59, default=1, has_default=True),
        "secondStep": number(1, 59, default=1, has_default=True),
    },
}


def validate_date(value: Any, fmt: str) -> None:
    formats = {"YYYY": "%Y", "YYYY-MM": "%Y-%m", "YYYY-MM-DD": "%Y-%m-%d", "YYYY-MM-DD HH": "%Y-%m-%d %H", "YYYY-MM-DD HH:mm": "%Y-%m-%d %H:%M", "YYYY-MM-DD HH:mm:ss": "%Y-%m-%d %H:%M:%S", "HH:mm": "%H:%M", "HH:mm:ss": "%H:%M:%S"}
    if fmt not in formats or not isinstance(value, str):
        reject("INVALID_DATE", "缺少有效日期/时间格式。")
    try:
        parsed = datetime.strptime(value, formats[fmt])
        if parsed.strftime(formats[fmt]) != value:
            reject("INVALID_DATE", "日期/时间格式不匹配。")
    except ValueError:
        reject("INVALID_DATE", "日期/时间值无效。")


def validate_compound(node: dict[str, Any], prop: str, value: Any, original: list[dict[str, Any]], candidate: list[dict[str, Any]]) -> None:
    component = node["componentName"]
    props = node.get("props", {})
    if prop == "disabledDays" and value is not None:
        if not isinstance(value, dict) or set(value) != {"enabled", "days"} or type(value["enabled"]) is not bool or not isinstance(value["days"], list):
            reject("INVALID_WEEKDAYS", "可选星期必须有 enabled 和 days。")
        if any(day not in [str(i) for i in range(7)] for day in value["days"]) or len(set(value["days"])) != len(value["days"]):
            reject("INVALID_WEEKDAYS", "星期必须是唯一的 0–6 字符串。")
        if value["enabled"] and (not value["days"] or props.get("format") in ("YYYY", "YYYY-MM")):
            reject("INVALID_WEEKDAYS", "年/月格式不支持可选星期；空数组不能表示禁止全部日期。")
    if prop in ("minTimeCondition", "maxTimeCondition") and value is not None:
        if not isinstance(value, dict) or value.get("enabled") is not True:
            reject("INVALID_TIME_CONDITION", "时间范围必须启用或显式置 null。")
        source = value.get("source")
        common = {"enabled", "source"}
        if source == "fixed":
            if set(value) != common | {"fixedValue"}:
                reject("INVALID_TIME_CONDITION", "固定时间范围不能残留其他 source 分支。")
            validate_date(value["fixedValue"], props.get("format"))
        elif source == "field":
            if set(value) != common | {"fieldName"}:
                reject("INVALID_TIME_CONDITION", "字段时间范围不能残留其他分支。")
            matches = [n for n in candidate if n.get("props", {}).get("name") == value["fieldName"]]
            if len(matches) != 1 or matches[0]["id"] == node["id"] or matches[0]["componentName"] != component:
                reject("INVALID_REFERENCE", "时间范围必须引用其他真实同类字段。")
        elif source == "dynamic":
            mode = value.get("dynamicMode")
            if mode == "current":
                allowed = common | {"dynamicMode"} | ({"dynamicAnchor"} if component == "DatePicker" else set())
                anchors = {"today", "currentWeek", "currentMonth", "nextMonth", "currentQuarter", "currentYear"}
                if set(value) - allowed or component == "DatePicker" and value.get("dynamicAnchor") not in anchors:
                    reject("INVALID_TIME_CONDITION", "动态当前时间分支参数无效。")
            elif component == "DatePicker" and mode in ("before", "after"):
                if set(value) != common | {"dynamicMode", "dynamicUnit", "offsetValue"} or value["dynamicUnit"] not in ("day", "week", "month", "quarter", "year"):
                    reject("INVALID_TIME_CONDITION", "动态日期偏移分支无效。")
                validate_schema(value["offsetValue"], {"type": "number", "minimum": 0})
            else:
                reject("INVALID_TIME_CONDITION", "时间仅支持 current；日期偏移需要完整参数。")
        else:
            reject("INVALID_TIME_CONDITION", "时间范围 source 未注册。")
        low, high = props.get("minTimeCondition"), props.get("maxTimeCondition")
        if isinstance(low, dict) and isinstance(high, dict) and low.get("source") == high.get("source") == "fixed" and low.get("enabled") and high.get("enabled") and low.get("fixedValue", "") > high.get("fixedValue", ""):
            reject("INVALID_RANGE", "最早时间不能晚于最晚时间。")


def snapshot(node: Mapping[str, Any], prop: str) -> dict[str, Any] | None:
    return default_snapshot(node.get("props", {})) if prop == "defaultValue" else None


def clear(node: Mapping[str, Any], prop: str) -> dict[str, Any] | None:
    if prop == "defaultValue":
        return {"exists": True, "value": {"mode": "undefined"}}
    if prop in ("disabledDays", "minTimeCondition", "maxTimeCondition"):
        return {"exists": True, "value": None}
    return None


def validate(node: Mapping[str, Any], prop: str, value: Any) -> bool:
    if prop != "defaultValue":
        return False
    validate_default(value, "string", "systemDate" if node["componentName"] == "DatePicker" else "systemTime")
    if value["mode"] == "custom":
        validate_date(value["value"], node.get("props", {}).get("format"))
    return True


def simulate(node: dict[str, Any], prop: str, after: Mapping[str, Any]) -> list[str] | None:
    return simulate_default(node["props"], after.get("value")) if prop == "defaultValue" else None


def effects(node: dict[str, Any], prop: str, value: Any, previous: Any) -> list[str] | None:
    props = node["props"]
    if prop == "format" and node["componentName"] == "DatePicker" and previous != value:
        props["placeholder"] = value.replace("YYYY", "年").replace("MM", "月").replace("DD", "日").replace("HH", "时").replace("mm", "分").replace("ss", "秒")
        if value in ("YYYY", "YYYY-MM"):
            props["disabledDays"] = None
        return ["仅真实日期格式变更触发占位提示更新；年/月格式清空可选星期"]
    if prop in ("minTimeCondition", "maxTimeCondition"):
        result = ["按 source 替换范围分支并验证同类字段引用及上下界"]
        if isinstance(value, dict) and value.get("dynamicMode") in ("before", "after"):
            result.append("日期 day/week/month/quarter/year 使用 1/7/30/90/365 天近似偏移")
        return result
    if prop == "disabledDays":
        return ["days 表示允许选择的星期；null 关闭限制，不用空数组表示全部禁用"]
    return None


def dependencies(prop: str) -> tuple[str, ...]:
    return ("format",) if prop in ("defaultValue", "disabledDays", "minTimeCondition", "maxTimeCondition") else ()
